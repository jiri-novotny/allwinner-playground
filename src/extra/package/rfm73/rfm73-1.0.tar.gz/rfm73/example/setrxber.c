#include <stdlib.h>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <string.h>
#include <linux/if.h>
#include <linux/if_packet.h>
#include <linux/if_arp.h>
#include <arpa/inet.h>
#include <unistd.h>

#define ETH_P_NONE      0x00FF
#define GET_RSSI        SIOCDEVPRIVATE //...+15
#define GET_CHANNEL     SIOCDEVPRIVATE + 1 //...+15
#define SET_CHANNEL     SIOCDEVPRIVATE + 2 //...+15
#define SET_FREQ        SIOCDEVPRIVATE + 3 //...+15
#define SET_POWER       SIOCDEVPRIVATE + 4 //...+15
#define SET_MODE        SIOCDEVPRIVATE + 5 //...+15
#define SET_RX_BER      SIOCDEVPRIVATE + 6 //...+15

// Kontrola chybovosti probiha pouze do "CHECK_BYTES" prijatych bytes.
#define CHECK_BYTES     500
// 500 bytes = PN9
#define BER_LEN         500
// delka RX Bloku dat vycitaneho z RX FIFO
#define RX_BLOCK_LEN    25

// X^16 + X^12 + X^5 + 1; CCITT
#define POLYM           0x1021
// Start value
#define SEED            0x1D0F

// "Rx data processing" variables
// pocitadlo naplneni payloadu
uint16_t p_cnt = 0;
// flag - all data received
uint8_t packet_received = 0;
// PN9 testing (BER Test)
// pn9_low registr
uint8_t       pn9_low;
// pn9_high registr
uint8_t       pn9_high;
// pn9 pomocny registr
uint8_t       pn9_pom;
// srovnani aktualni hodnoty a PN9
uint8_t       compare_b;

unsigned char data[1024];

uint16_t packet_crc(uint8_t *packet, uint8_t packet_len, uint8_t crc_shift)
{
  uint8_t i, j, data;
  // pocatecni hodnota
  uint16_t crc = SEED;
  for (i = 0; i < packet_len; i++)
  {
    data = *(packet + i + crc_shift);
    for (j = 0; j < 8; j++)
    {
      if ((((crc & 0x8000) >> 8) ^ (data & 0x80)) != 0)
      {
        // shift left once
        crc <<= 1;
        // XOR with polynomial
        crc ^= POLYM;
      }
      else
      {
        // shift left once
        crc <<= 1;
      }
      // next data bit
      data <<= 1;
    }
    // one byte is completed
  }
  // packet is completed
  return crc;
}

uint8_t rx_pckt_processing_ber(uint16_t *p_err_bit_count)
{
  // lokalni promenne
  uint8_t i, k;
  uint8_t byte_w = 0;
  // RX_BLOCK_LEN processing - zpracovani bloku dat z Rx FIFO
  for (i = 0; i < RX_BLOCK_LEN; i++)
  {
    // pracovni byte
    byte_w = data [i];
    // vypocet poctu bitovych chyb
    if (p_cnt <= BER_LEN) {
       // pocitadlo chybnych bitu
       // do chyb se zapocte pouze prvnich "CHECK_BYTES" bajtu. 
      // porovnani PN9 a prijatych dat
       compare_b = (p_cnt <= CHECK_BYTES)? pn9_low ^ byte_w : 0;
       for (k = 0; k < 8; k++)
       {
         // inkrementuj pocitadlo chybnych bitu
         if ((compare_b >> k)& 0x01) (*p_err_bit_count)++;
       }
       // vypocet pristi hodnoty PN9 - 8 x rotace
       for (k = 0; k < 8; k++)
       {
         // XOR bitu 0 a bitu 5
         pn9_pom = ((pn9_low & 0x01)^((pn9_low>>5) & 0x01));
         // posun vpravo doplnen zleva o 9 bit
         pn9_low = (pn9_low>>1) | ((pn9_high & 0x01)<<7);
         // uloz novou hodnotu 9. bitu
         pn9_high = pn9_pom;
       }
       // inkrementace pocitadla payloadu (1 - 500)
       p_cnt++;
    }
    else  {
      // checking complete - nastaveni priznaku
      return 1;
    }
    // cti dalsi byte
  }

  // checking not complete yet
  return 0;
}
 
int main(int argc, char * argv[])
{
  int sock = -1;
  double freq;
  struct ifreq req;
  struct sockaddr_ll sll;

  int i;
  int len;
  int rssi = 0;
  uint16_t use_led = 0;
  uint16_t pckt_count = 0;
  uint16_t err_bit_count = 0;
  uint16_t crc = 0;
  uint8_t resp[32] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 'J', 'A', '-', '2', '2', 'K', 0x20, '0', 0x00};
  

  if (argc <= 3)
  {
    fprintf(stdout, "USAGE: %s rf_name frequency sn [use_led] [ctr]\n", argv[0]);
    return 0;
  }
  resp[13] = argv[3][0];

  sock = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_NONE));

  strncpy((char *) req.ifr_name, argv[1], IFNAMSIZ);
  if ((ioctl(sock, SIOCGIFINDEX, &req)) < 0)
  {
    fprintf(stderr, "Socket index failed for %s\n", argv[1]);
    close(sock);
    return 2;
  }
  
  /* Bind our raw socket to this interface */
  sll.sll_family = AF_PACKET,
  sll.sll_protocol = htons(ETH_P_NONE),
  sll.sll_ifindex = req.ifr_ifindex;

  if ((bind(sock, (struct sockaddr *) &sll, sizeof(sll))) < 0)
  {
    fprintf(stderr, "Socket bind failed for %s\n", argv[1]);
    return -3;
  }

  sscanf(argv[2], "%lf", &freq);
  req.ifr_flags = (freq * 2097152) / 52000000;
  if (ioctl(sock, SET_FREQ, &req) < 0)
  {
    fprintf(stderr, "Set frequency failed");
    close(sock);
    return 3;
  }

  req.ifr_flags = 1;
  if (ioctl(sock, SET_RX_BER, &req) < 0)
  {
    fprintf(stderr, "Set mode failed");
    close(sock);
    return 4;
  }
  
  if (argc >= 5)
  {
    sscanf(argv[4], "%hu", &use_led);
  }
  else
  {
    use_led = 0;
  }

  if (argc >= 6)
  {
    sscanf(argv[5], "%hu", &pckt_count);
  }
  else
  {
    pckt_count = 0;
  }

  while (1)
  {
    // inicializace generatoru PN9 posloupnosti
    pn9_low = 0xFF;
    pn9_high = 0xFF;
    // inicializace pocitadla chybnych bitu
    err_bit_count = 0;
    // nastaveni pocitadla prijatych bytes payloadu
    p_cnt = 1;
    // Schozeni flagu prijatych dat
    packet_received = 0;

    printf("Packet data: {\n");
    while (packet_received == 0)
    {
      len = recvfrom(sock, data, sizeof(data), 0, NULL, NULL);
      if (len < 0) continue;
      if (len == 0)
      {
        printf("EOF received.\n");
      }
      else
      {
        for (i = 0; i < len; ++i)
        {
          printf("%02x ", data[i]);
        }
        printf("\n");
        
        packet_received = rx_pckt_processing_ber(&err_bit_count);
      }
    }

    printf("}\n");
    printf("packet: %d\n", ++pckt_count);
    printf("BER: %u\n", err_bit_count);
    printf("rssi: %d\n", rssi);

    /* send response to UI */
    //memcpy(resp, &err_bit_count, 2);
    resp[0] = ((err_bit_count >> 8) & 0x00FF);
    resp[1] = ((err_bit_count) & 0x00FF);
    //memcpy(resp + 2, &pckt_count, 2);
    resp[2] = ((pckt_count >> 8) & 0x00FF);
    resp[3] = ((pckt_count) & 0x00FF);
    resp[4] = -1 * rssi;
    crc = packet_crc(resp, 30, 0);
    //memcpy(resp + 30, &crc, 2);
    resp[30] = ((crc >> 8) & 0x00FF);
    resp[31] = ((crc) & 0x00FF);
    for (i = 0; i < 32; ++i)
    {
      printf("%02x ", resp[i]);
    }
    printf("\n");
    len = send(sock, resp, 32, 0);
    usleep(10000);

    if (use_led)
    {
      system("echo 1 > /sys/class/leds/power/shot");
    }

    if (ioctl(sock, GET_RSSI, &req) < 0)
    {
      fprintf(stderr, "Get RSSI failed\n");
      rssi = 0;
    }
    else
    {
      rssi = req.ifr_flags;
    }

    /* reinit BER mode */
    req.ifr_flags = 1;
    if (ioctl(sock, SET_RX_BER, &req) < 0)
    {
      fprintf(stderr, "Set mode failed");
      close(sock);
      return 4;
    }
    /* flush rest */
    for (i = 0; i < 20; i++)
    {
      usleep(30000);
      len = recvfrom(sock, data, sizeof(data), MSG_DONTWAIT, NULL, NULL);
    }
    
    printf("******\n");
  }

  req.ifr_flags = 0;
  if (ioctl(sock, SET_RX_BER, &req) < 0)
  {
    fprintf(stderr, "Set mode failed");
    close(sock);
    return 4;
  }
  
  close(sock);
  return 0;
}
