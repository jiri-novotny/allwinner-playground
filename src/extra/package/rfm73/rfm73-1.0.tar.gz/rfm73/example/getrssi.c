#include <stdlib.h>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <string.h>
#include <linux/if.h>
#include <linux/if_packet.h>
#include <linux/if_arp.h>
#include <arpa/inet.h>
#include <unistd.h>

#define ETH_P_NONE 0x00FF
#define SET_CHANNEL SIOCDEVPRIVATE

int main(int argc, char * argv[])
{
	int sock = -1;
	struct ifreq req;

	if (argc <= 1)
	{
		fprintf(stdout, "USAGE: %s rf_name\n", argv[0]);
		return 0;
	}

	sock = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_NONE));
	strncpy((char *) req.ifr_name, argv[1], IFNAMSIZ);
	if ((ioctl(sock, SIOCGIFINDEX, &req)) < 0)
	{
		fprintf(stderr, "Socket index failed for %s\n", argv[1]);
		close(sock);
		return 2;
	}

	if (ioctl(sock, SIOCDEVPRIVATE, &req) < 0)
	{
		fprintf(stderr, "Get RSSI failed\n");
		close(sock);
		return 3;
	}
	printf("RSSI: %d\n", req.ifr_flags);

	close(sock);
	return 0;
}
