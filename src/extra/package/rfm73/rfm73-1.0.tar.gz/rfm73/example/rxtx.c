#include <stdlib.h>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <string.h>
#include <linux/if.h>
#include <linux/if_packet.h>
#include <linux/if_arp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>

#define ETH_P_NONE 0x00FF

int run;
int sock = -1;

void *recvthr(void *arg)
{
	int i;
	int len;
	int rssi = 0;
	unsigned char rxbuf[128];

	while (run)
	{
		len = recvfrom(sock, rxbuf, sizeof(rxbuf), 0, NULL, NULL);

		if (len < 0) continue;
		if (len == 0)
		{
			printf("EOF received.\n");
		}
		else
		{
			printf("Packet from: %02x, to: %02x, len %d, rssi: %d\ndata: { ", rxbuf[1], rxbuf[0], len, rssi);
			for (i = 2; i < len; ++i)
			{
				printf("%02x ", rxbuf[i]);
			}
			printf("}\n");
		}
	}

	pthread_exit(NULL);
}

int main(int argc, char * argv[])
{
	unsigned char txbuf[128];
	char *line;
	int len;
	pthread_t thr;
	struct ifreq req;
	struct sockaddr_ll sll;

	if (argc <= 1)
	{
		fprintf(stdout, "USAGE: %s rf_name\n", argv[0]);
		return -1;
	}
	
	sock = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_NONE));
	strncpy((char *) req.ifr_name, argv[1], IFNAMSIZ);
	if ((ioctl(sock, SIOCGIFINDEX, &req)) < 0)
	{
		fprintf(stderr, "Socket index failed for %s\n", argv[1]);
		return -2;
	}
	/* Bind our raw socket to this interface */
	sll.sll_family = AF_PACKET,
	sll.sll_protocol = htons(ETH_P_NONE),
	sll.sll_ifindex = req.ifr_ifindex;
	if ((bind(sock, (struct sockaddr *) &sll, sizeof(sll))) < 0)
	{
		fprintf(stderr, "Socket bind failed for %s\n", argv[1]);
		return -3;
	}

	run = 1;
	pthread_create(&thr, NULL, recvthr, NULL);
	while (run)
	{
		getline(&line, &len, stdin);
		if (0 == strncmp("quit", line, 4))
		{
			run = 0;
		}
		else
		{
			sscanf(line, "%x", (unsigned int *) &txbuf[0]);
			memcpy(txbuf + 1, line + 2, len - 2);
			len = strlen((char *)(txbuf + 1));
			len = send(sock, txbuf, len + 1, 0);
			if (len >= 0)
			{
				printf("send: %d\n", len);
			}
			else
			{
				printf("err send: %s\n", strerror(errno));
			}
		}
	}

	close(sock);
	pthread_join(thr, NULL);

	return 0;
}
