#include <stdlib.h>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <string.h>
#include <linux/if.h>
#include <linux/if_packet.h>
#include <linux/if_arp.h>
//#include <linux/uio.h>
#include <arpa/inet.h>
#include <unistd.h>

#define ETH_P_NONE 0x00FF

int main(int argc, char * argv[])
{
	int sock;
	int len;
	unsigned char buf[128];
	struct ifreq req;
	struct sockaddr_ll sll;

	if (argc <= 2)
	{
		fprintf(stdout, "USAGE: %s rf_name addr payload\n", argv[0]);
		return -1;
	}
	
	sock = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_NONE));
	strncpy((char *) req.ifr_name, argv[1], IFNAMSIZ);
	if ((ioctl(sock, SIOCGIFINDEX, &req)) < 0)
	{
		fprintf(stderr, "Socket index failed for %s\n", argv[1]);
		return -2;
	}

	/* Bind our raw socket to this interface */
	sll.sll_family = AF_PACKET,
	sll.sll_protocol = htons(ETH_P_NONE),
	sll.sll_ifindex = req.ifr_ifindex;

	if ((bind(sock, (struct sockaddr *) &sll, sizeof(sll))) < 0)
	{
		fprintf(stderr, "Socket bind failed for %s\n", argv[1]);
		return -3;
	}

	sscanf(argv[2], "%x", &buf[0]);
	len = strlen(argv[3]);
	memcpy(buf + 1, argv[3], len);
	len = send(sock, buf, len + 1, 0);
	if (len >= 0)
	{
		printf("send: %d\n", len);
	}
	else
	{
		printf("err send: %d\n%s\n", len, strerror(errno));
	}

	close(sock);
}
