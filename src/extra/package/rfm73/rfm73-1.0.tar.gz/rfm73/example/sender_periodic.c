#include <stdlib.h>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <string.h>
#include <linux/if.h>
#include <linux/if_packet.h>
#include <linux/if_arp.h>
#include <arpa/inet.h>
#include <unistd.h>

#define ETH_P_NONE 0x00FF

int main(int argc, char * argv[])
{
	int sock;
	int len;
	unsigned int i = 0;
	int sleepTime;
	unsigned char buf[128];
	struct ifreq req;
	struct sockaddr_ll sll;

	if (argc <= 3)
	{
		fprintf(stdout, "USAGE: %s rf_name addr payload sleep\n", argv[0]);
		return -1;
	}
	
	sock = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_NONE));
	strncpy((char *) req.ifr_name, argv[1], IFNAMSIZ);
	if ((ioctl(sock, SIOCGIFINDEX, &req)) < 0)
	{
		fprintf(stderr, "Socket index failed for %s\n", argv[1]);
		return -2;
	}

	/* Bind our raw socket to this interface */
	sll.sll_family = AF_PACKET,
	sll.sll_protocol = htons(ETH_P_NONE),
	sll.sll_ifindex = req.ifr_ifindex;

	if ((bind(sock, (struct sockaddr *) &sll, sizeof(sll))) < 0)
	{
		fprintf(stderr, "Socket bind failed for %s\n", argv[1]);
		return -3;
	}

	if (1 != sscanf(argv[4], "%d", &sleepTime))
	{
		sleepTime = 500000;
	}
	buf[0] = 0x0;
	while (1)
	{
		i++;
		sprintf(buf + 5, " %s%d", argv[3], i);
		len = strlen(buf + 5) + 6;
		memcpy(buf + 2, &i, 4);
		len = send(sock, buf, len, 0);
		if (len >= 0)
		{
			//printf("send: %d\n", len);
			system("echo 1 > /sys/class/leds/gsm/shot");
		}
		else
		{
			printf("err send: %d\n%s\n", len, strerror(errno));
		}
		usleep(sleepTime);
	}
	close(sock);
}
