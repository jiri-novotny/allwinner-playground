#include <stdlib.h>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <string.h>
#include <linux/if.h>
#include <linux/if_packet.h>
#include <linux/if_arp.h>
#include <arpa/inet.h>
#include <unistd.h>

#define ETH_P_NONE 0x00FF

int main(int argc, char * argv[])
{
	unsigned char buf[128];
	int len;
	int sock;
	int i;
	unsigned int j = 0;
	unsigned int k = 0;
	struct ifreq req;
	struct sockaddr_ll sll={
		.sll_family = AF_PACKET,
		.sll_protocol = htons(ETH_P_NONE),
	};

	if (argc <= 1)
	{
		fprintf(stdout, "USAGE: %s rf_name\n", argv[0]);
		return -1;
	}
	
	sock = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_NONE));
	strncpy((char *) req.ifr_name, argv[1], IFNAMSIZ);
	if ((ioctl(sock, SIOCGIFINDEX, &req)) < 0)
	{
		fprintf(stderr, "Socket index failed for %s\n", argv[1]);
		return -2;
	}
	/* Bind our raw socket to this interface */
	sll.sll_ifindex = req.ifr_ifindex;
	if ((bind(sock, (struct sockaddr *) &sll, sizeof(sll))) < 0)
	{
		fprintf(stderr, "Socket bind failed for %s\n", argv[1]);
		return -3;
	}

	while (1)
	{
		j++;
		len = recvfrom(sock, buf, sizeof(buf), 0, NULL, NULL);
		if (len < 0) continue;
		if (len == 0) printf("EOF received.\n");
		else
		{
			if (j != *(unsigned int *) &buf[2])
			{
				fprintf(stderr, "Packet err %u, %u\n", j, k);
				j = *(unsigned int *) &buf[2];
				k++;
			}
			else system("echo 1 > /sys/class/leds/gsm/shot");/*
			{
				printf("data: { ");
				for (i = 0; i < len; ++i)
				{
					printf("%02x ", buf[i]);
				}
				printf("}, len: %d\n", len);
			}*/
		}
	}

	close(sock);
}
