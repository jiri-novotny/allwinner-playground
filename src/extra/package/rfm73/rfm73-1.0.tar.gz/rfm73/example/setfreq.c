#include <stdlib.h>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <string.h>
#include <linux/if.h>
#include <linux/if_packet.h>
#include <linux/if_arp.h>
#include <arpa/inet.h>
#include <unistd.h>

#define ETH_P_NONE      0x00FF
#define GET_RSSI        SIOCDEVPRIVATE //...+15
#define GET_CHANNEL     SIOCDEVPRIVATE + 1 //...+15
#define SET_CHANNEL     SIOCDEVPRIVATE + 2 //...+15
#define SET_FREQ        SIOCDEVPRIVATE + 3 //...+15
#define SET_POWER       SIOCDEVPRIVATE + 4 //...+15
#define SET_MODE        SIOCDEVPRIVATE + 5 //...+15

int main(int argc, char * argv[])
{
	int sock = -1;
	double freq;
	struct ifreq req;

	if (argc <= 3)
	{
		fprintf(stdout, "USAGE: %s rf_name test_mode frequency\n", argv[0]);
		return 0;
	}

	sock = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_NONE));

	strncpy((char *) req.ifr_name, argv[1], IFNAMSIZ);
	if ((ioctl(sock, SIOCGIFINDEX, &req)) < 0)
	{
		fprintf(stderr, "Socket index failed for %s\n", argv[1]);
		close(sock);
		return 2;
	}

	sscanf(argv[3], "%lf", &freq);
	req.ifr_flags = (freq * 2097152) / 52000000;
	if (ioctl(sock, SET_FREQ, &req) < 0)
	{
		fprintf(stderr, "Set frequency failed");
		close(sock);
		return 3;
	}

	sscanf(argv[2], "%04hx", &req.ifr_flags);
	if (ioctl(sock, SET_MODE, &req) < 0)
	{
		fprintf(stderr, "Set mode failed");
		close(sock);
		return 4;
	}

	close(sock);
	return 0;
}
