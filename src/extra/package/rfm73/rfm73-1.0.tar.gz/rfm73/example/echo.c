#include <stdlib.h>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <string.h>
#include <linux/if.h>
#include <linux/if_packet.h>
#include <linux/if_arp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <openssl/conf.h>
#include <openssl/evp.h>
#include <openssl/err.h>

#define ETH_P_NONE 0x00FF

void handleErrors(void)
{
	ERR_print_errors_fp(stderr);
	abort();
}

int encrypt(unsigned char *in, int inlen, unsigned char *key, unsigned char *iv, unsigned char *out)
{
	EVP_CIPHER_CTX *ctx;

	int len;
	int outlen;

	if (!(ctx = EVP_CIPHER_CTX_new()))
	{
		handleErrors();
	}

	if (1 != EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv))
	{
		handleErrors();
	}

	if (1 != EVP_EncryptUpdate(ctx, out, &len, in, inlen))
	{
		handleErrors();
	}
	outlen = len;

	if (1 != EVP_EncryptFinal_ex(ctx, out + len, &len))
	{
		handleErrors();
	}
	outlen += len;

	/* Clean up */
	EVP_CIPHER_CTX_free(ctx);

	return outlen;
}

int decrypt(unsigned char *in, int inlen, unsigned char *key, unsigned char *iv, unsigned char *out)
{
	EVP_CIPHER_CTX *ctx;

	int len;
	int outlen;

	if (!(ctx = EVP_CIPHER_CTX_new()))
	{
		handleErrors();
	}

	if (1 != EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv))
	{
		handleErrors();
	}

	if (1 != EVP_DecryptUpdate(ctx, out, &len, in, inlen))
	{
		handleErrors();
	}
	outlen = len;

	if (1 != EVP_DecryptFinal_ex(ctx, out + len, &len))
	{
		handleErrors();
	}
	outlen += len;

	EVP_CIPHER_CTX_free(ctx);

	return outlen;
}

int main(int argc, char * argv[])
{
	int sock;
	int len;
	int i = 0;
	unsigned char rxbuf[128];
	unsigned char txbuf[128];
	struct ifreq req;
	struct sockaddr_ll sll;

	if (argc <= 1)
	{
		fprintf(stdout, "USAGE: %s rf_name\n", argv[0]);
		return -1;
	}
	
	sock = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_NONE));
	strncpy((char *) req.ifr_name, argv[1], IFNAMSIZ);
	if ((ioctl(sock, SIOCGIFINDEX, &req)) < 0)
	{
		fprintf(stderr, "Socket index failed for %s\n", argv[1]);
		return -2;
	}

	/* Bind our raw socket to this interface */
	sll.sll_family = AF_PACKET,
	sll.sll_protocol = htons(ETH_P_NONE),
	sll.sll_ifindex = req.ifr_ifindex;

	if ((bind(sock, (struct sockaddr *) &sll, sizeof(sll))) < 0)
	{
		fprintf(stderr, "Socket bind failed for %s\n", argv[1]);
		return -3;
	}

	unsigned char *key = (unsigned char *) "0123456789012345";
	unsigned char *iv = (unsigned char *) "0123";

	unsigned char ciphertext[128];
	unsigned char decryptedtext[128];
	/* Message to be encrypted */
	unsigned char *plaintext;
	int plaintext_len;
	int ciphertext_len;
	int decryptedtext_len;

	while (1)
	{
		len = recvfrom(sock, rxbuf, sizeof(rxbuf), 0, NULL, NULL);

		if (len < 0) continue;
		if (len == 0)
		{
			printf("EOF received.\n");
		}
		else
		{
			printf("Packet from: %02x, to: %02x, len %d, rssi: %d\ndata: { ", rxbuf[1], rxbuf[0], len, 0);
			
			for (i = 2; i < len; ++i)
			{
				printf("%02x ", rxbuf[i]);
				/* this simulates response modification */
				txbuf[i] = rxbuf[len - i];
			}
			printf("}\n");

			/* this block simulates decryption of packet and encryption of response */
			plaintext = rxbuf + 2;
			plaintext_len = 16;;
			ciphertext_len = encrypt (plaintext, plaintext_len, key, iv, ciphertext);
			/* Decrypt the ciphertext */
			decryptedtext_len = decrypt(ciphertext, ciphertext_len, key, iv, decryptedtext);
			/* Add a NULL terminator. We are expecting printable text */
			decryptedtext[decryptedtext_len] = '\0';

			/* store target address */
			txbuf[0] = rxbuf[1];
			/* stire my address - not neccessary (handled by driver) */
			txbuf[1] = 1;
			len = send(sock, txbuf, len, 0);
			if (len >= 0)
			{
				printf("send: %d\n", len);
			}
			else
			{
				printf("err send: %d\n%s\n", len, strerror(errno));
			}
		}
	}

	close(sock);
}
